#include "WarheadStructureDlg.h"
#include "ui_warheadstructure.h"
#include <WarheadReadWrite/warhead_read.h>
#include <WarheadDraw/warhead_draw_wnd.h>
#include <ExpandQtCore/expandqtcore.h>

QString g_warhead_file;

WarheadStructureDlg::WarheadStructureDlg(WarheadModel** warhead, QWidget* parent)
	: QDialog(parent)
	, warhead_(warhead)
	, ui_(new Ui::WarheadStructure)
	, draw_wnd_(new WarheadDrawWnd(WarheadDrawWnd::kView, 0, this))
	, temp_warhead_(0)
{
	ui_->setupUi(this);
	ui_->lineEdit->setEnabled(false);
	QVBoxLayout* layout = new QVBoxLayout(ui_->widget);
	layout->addWidget(draw_wnd_);

	if(*warhead_)
	{
		ui_->widget_select->hide();
		draw_wnd_->set_model(*warhead_);
	}
	connect(ui_->toolButton_select, SIGNAL(clicked()), this, SLOT(on_select_warhead()));
	connect(ui_->lineEdit, SIGNAL(textChanged(const QString&)), this, SLOT(on_warhead_changed(const QString&)));
	ui_->lineEdit->setText(g_warhead_file);
}


WarheadStructureDlg::~WarheadStructureDlg(void)
{
	delete ui_;
}

void WarheadStructureDlg::accept()
{
	if(temp_warhead_)
	{
		*warhead_ = temp_warhead_;
		g_warhead_file = ui_->lineEdit->text();
	}
	QDialog::accept();
}
void WarheadStructureDlg::reject()
{
	if(temp_warhead_)
		delete temp_warhead_;
	QDialog::reject();

}
void WarheadStructureDlg::on_select_warhead()
{
	QString file_name = QFileDialog::getOpenFileName(this, ExpandQtCore::fromGBK("��"), QString(), ExpandQtCore::fromGBK("ս����ģ�� (*.whd)"));
	if(!file_name.isEmpty())
	{
		ui_->lineEdit->setText(file_name);
	}
}

void WarheadStructureDlg::on_warhead_changed(const QString& text)
{
	WarheadRead reader;
	if(temp_warhead_)
		delete temp_warhead_;
	temp_warhead_ = reader.ReadXMLFile(ui_->lineEdit->text());
	draw_wnd_->set_model(temp_warhead_);
}
