#pragma once
#include <QtWidgets>

class PowerAnalysis;
class WarheadModel;
class SubProcedureData;
class CountTaskData;
namespace Ui { class TaskConfig; }
class TaskConfigDlg :
	public QDialog
{
	Q_OBJECT
public:
	TaskConfigDlg(PowerAnalysis* power_analysis, const WarheadModel* warhead, QWidget* parent=0);
	virtual ~TaskConfigDlg(void);
public slots:
	void on_task_state_changed(bool checked);
protected:
	PowerAnalysis* power_analysis_;
	const WarheadModel* warhead_;
	Ui::TaskConfig* ui_;
	QMap<QCheckBox*, const CountTaskData*> box_2_task_;
	void InitUi();
	QWidget* CreateSubProcedurePage(const SubProcedureData* sub_procedure);
};

