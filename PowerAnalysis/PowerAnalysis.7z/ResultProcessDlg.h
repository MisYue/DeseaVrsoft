#pragma once
#include <QtWidgets>

class PowerAnalysis;
class OperatorDictionary;
class SubProcedureData;
class QDomElement;
namespace Ui { class FormulaCount; }
class ResultProcessDlg :
	public QDialog
{
	Q_OBJECT
public:
	ResultProcessDlg(PowerAnalysis* power_analysis, const OperatorDictionary* dict, QWidget* parent=0);
	virtual ~ResultProcessDlg(void);
public slots:
	void on_export();
protected:
	PowerAnalysis* power_analysis_;
	const OperatorDictionary* dict_;
	Ui::FormulaCount* ui_;
	QVector< QPair<QListWidget*, QVector<QWidget*> > > result_pages_;
	void InitUi();
	QWidget* CreateSubProcedurePage(const SubProcedureData* sub_procedure);
	QWidget* CreateResultShowPage(const QString& result_xml);

	QString FormatOutUnitSystem(QDomElement* element, char space);
	QString FormatOutCsv(QDomElement* element, char space);
};

