#pragma once
#include <QtWidgets>

class WarheadModel;
class WarheadDrawWnd;
namespace Ui { class WarheadStructure; }
class WarheadStructureDlg :
	public QDialog
{
	Q_OBJECT
public:
	WarheadStructureDlg(WarheadModel** warhead, QWidget* parent=0);
	virtual ~WarheadStructureDlg(void);
public slots:
	void accept();
	void reject();
	void on_select_warhead();
	void on_warhead_changed(const QString& text);
protected:
	WarheadModel** warhead_;
	WarheadModel* temp_warhead_;
	Ui::WarheadStructure* ui_;
	WarheadDrawWnd* draw_wnd_;
};

