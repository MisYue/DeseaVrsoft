#include "PowerAnalysisBaseData.h"
#include <WarheadModelData/warhead_model.h>
#include <WarheadMaterialLib/warheadmateriallib.h>

PowerAnalysisBaseData::PowerAnalysisBaseData(const WarheadModel* warhead)
	: warhead_(warhead)
{
	//Q_ASSERT(warhead_);
}


PowerAnalysisBaseData::~PowerAnalysisBaseData(void)
{
	if(warhead_)
		delete warhead_;
}
void PowerAnalysisBaseData::set_warhead(WarheadModel* warhead) 
{
	if(warhead_ && warhead_ != warhead)
	{
		delete warhead_;
		warhead_ = warhead; 
	}
}

//��ȡ��������
QString PowerAnalysisBaseData::GetData(const QString& key) const
{
	//������������չƵ��ʱ�����Կ���ʹ�ýű�
	WarheadCharacterData character_data = warhead_->get_character_data();
	Bit_UnitSystem us = warhead_->get_cs().Get_UnitSystem();
	if(key == "WARHEAD_TOTAL_MASS")
		return QString::number(character_data.mass);
	else if(key == "WARHEAD_CHARGE_MASS")
		return QString::number(character_data.charge_mass);
	else if(key == "LENGTH_COEF")
		return QString::number(us.Get_LengthUnit());
	else if(key == "MASS_COEF")
		return QString::number(us.Get_MassUnit());
	else if(key == "TIME_COEF")
		return QString::number(us.Get_TimeUnit());
	else if(key == "CHARGE_ID")
		return warhead_->GetChargeId();
	else if(key == "CHARGE_DENSITY")
		return QString::number(WarheadMaterialLib::intances().GetChargeDataById(warhead_->GetChargeId())->get_density(us));
	else if(key == "CHARGE_EXPLOSION_VELOCITY")
		return QString::number(WarheadMaterialLib::intances().GetChargeDataById(warhead_->GetChargeId())->get_velocity(us));
	else if(key == "CHARGE_EXPLOSION_HEAT")
		return QString::number(WarheadMaterialLib::intances().GetChargeDataById(warhead_->GetChargeId())->get_heat(us));
	else if(key == "CHARGE_EXPLOSIN_PRESSURE")
		return QString::number(WarheadMaterialLib::intances().GetChargeDataById(warhead_->GetChargeId())->get_pressure(us));
	return QString();
}